package Test;

import Connectors.Connector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Testing {
    public static void main(String[] args) throws SQLException, Exception {
        Connection conn = Connector.getConnection();
        
        String query = "INSERT INTO alumnos (id, nombre, apellido, edad, email, idCatedra) VALUES ('1', 'Richard', 'Lopez', '60', 'richardlopez@gmail.com','1')";
        Statement st = conn.createStatement();
        st.execute(query);
        
        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM alumnos");
        while (rs.next()) {
            System.out.println(
                rs.getInt("id") + ", " +
                rs.getString("nombre") + ", " +
                rs.getString("apellido") + ", " +
                rs.getString("edad") + ", " +
                rs.getString("email") + ","+  
                rs.getString("idCatedra")     
            );
        }
        
        // Cerrar la conexión y liberar recursos
        rs.close();
        st.close();
        conn.close();
    }
}
