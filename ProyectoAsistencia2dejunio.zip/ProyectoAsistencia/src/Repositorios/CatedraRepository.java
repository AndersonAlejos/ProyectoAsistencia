/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositorios;

import Entity.Catedra;
import Entity.Docente;
import Enums.Dia;
import Enums.Turno;
import Interfaces.ICatedraRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class CatedraRepository implements ICatedraRepository{
    
    private Connection conn;

    public CatedraRepository(Connection conn) {
        this.conn = conn;
    }
  
    @Override
    public void save(Catedra catedra) {
        if(catedra==null) return;
        //insert into alumnos (nombre,apellido,edad,idCurso) 
        // values ("Anonymus","+x',66,1); delete from docentes; -- +",?,?)",
        try (PreparedStatement ps=conn.prepareStatement(
                "insert into catedra (titulo,profesor,dia,turno) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS
        )) {
            ps.setString(1, catedra.getTitulo());
            ps.setString(2, catedra.getProfesor());
            ps.setString(3, catedra.getDia().toString());
            ps.setString(4, catedra.getTurno().toString());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) catedra.setId(rs.getInt(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void remove(Catedra catedra) {
        if(catedra==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from docentes where id=?")){
            ps.setInt(1, catedra.getId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Catedra catedra) {
        if(catedra==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
                "update docentes set nombre=?, apellido=?, email=?, idCatedra=? where id=?"
        )) {
            ps.setInt(5, catedra.getId());
            ps.setString(1, catedra.getTitulo());
            ps.setString(2, catedra.getProfesor());
            ps.setString(3, catedra.getDia().toString());
            ps.setString(4, catedra.getTurno().toString());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Catedra> getAll() {
        List<Catedra> lista=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from catedra")){
            while(rs.next()){
                lista.add(new Catedra(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getString("profesor"),
                        Dia.valueOf(rs.getString("dia")) ,
                        Turno.valueOf(rs.getString("turno")) 
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
    
}
