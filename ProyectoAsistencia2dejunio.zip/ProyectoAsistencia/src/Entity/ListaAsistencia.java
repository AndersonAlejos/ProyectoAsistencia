
package Entity;


public class ListaAsistencia {
    
}
