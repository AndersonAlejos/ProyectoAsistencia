package Interfaces;

import Entity.Catedra;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public interface ICatedraRepository {
    
    void save(Catedra catedra);
    void remove(Catedra catedra);
    void update(Catedra catedra);
    
    List<Catedra> getAll();
    default Stream<Catedra> getStream(){
        return getAll().stream();
    }
    default Catedra getById(int id){
        return getStream().filter(a->a.getId()==id).findAny().orElse(new Catedra());
   
         
    }
    default List<Catedra> getByCatedra(Catedra catedra){
        if(catedra==null) return new ArrayList<Catedra>();
        return getStream()
                .filter(a->a.getId()==catedra.getId())
                .collect(Collectors.toList());
    }
    
}