
package Interfaces;

import Entity.Catedra;
import Entity.Docente;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


public interface IDocenteRepository {
    
    void save(Docente docente);
    void remove(Docente docente);
    void update(Docente docente);
    
    List<Docente> getAll();
    default Stream<Docente> getStream(){
        return getAll().stream();
    }
    default Docente getById(int id){
        return getStream().filter(a->a.getId()==id).findAny().orElse(new Docente ());
    }
    default List<Docente> getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList<Docente>();
        return getStream()
                .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Docente> getByCatedra(Catedra catedra){
        if(catedra==null) return new ArrayList<Docente>();
        return getStream()
                .filter(a->a.getIdCatedra()==catedra.getId())
                .collect(Collectors.toList());
    }
    
}

