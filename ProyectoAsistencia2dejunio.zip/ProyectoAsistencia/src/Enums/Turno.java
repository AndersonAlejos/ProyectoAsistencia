package Enums;
public enum Turno { MAÑANA,TARDE,NOCHE }