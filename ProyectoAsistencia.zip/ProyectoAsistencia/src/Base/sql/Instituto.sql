drop database if exists instituto;
create database instituto;
use instituto;
drop table if exists alumnos;
drop table if exists catedra;
drop table if exists docente;

create table alumnos(
    id int auto_increment primary key,
    nombre varchar(45) not null,
    apellido varchar(45) not null,
    edad int,
    email varchar(45) not null,
    idCatedra int not null)

create table catedra(
    id int auto_increment primary key,
    titulo  varchar(45) not null,
    profesor varchar(45) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    turno enum('MAÑANA','TARDE','NOCHE'))

create table docente(
    id int auto_increment primary key,
    nombre varchar(45) not null,
    apellido varchar(45) not null,
    email varchar(45) not null,
    idCatedra int not null)
    

alter table alumnos ( 
    add constraint FK_alumnos_idCatedra
    foreign key(idCatedra)
    references catedra(id);
)

alter table docente( 
    add constraint FK_docente_idCatedra
    foreign key(idCatedra)
    references catedra(id);
)