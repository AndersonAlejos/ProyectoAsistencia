package Enums;
public enum Dia { LUNES,MARTES,MIERCOLES,JUEVES,VIERNES }