package Test;

import Connectors.Connector;
import Entity.Alumno;
import Interfaces.IAlumnoRepository;
import Repositorios.AlumnoRepository;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class TestAlumno {
    public static void main(String[] args) throws SQLException {
        Connection conn = (Connection) Connector.getConnection();

        // Crear una instancia de ProductoDAOImpl
        IAlumnoRepository alumno = new AlumnoRepository((java.sql.Connection) conn);
        
        Alumno alumnoExistente = new Alumno(1, "Luis", "Lopez", 20, "luislopez@gmail.com",1);
        
        
        alumno.update(alumnoExistente);
        
    }
}
