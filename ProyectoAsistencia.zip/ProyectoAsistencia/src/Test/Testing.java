package Test;

import Connectors.Connector;
import Entity.Alumno;
import Interfaces.IAlumnoRepository;
import Repositorios.AlumnoRepository;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Testing {
    public static void main(String[] args) throws SQLException, Exception {
//        Connection conn = Connector.getConnection();
//        
//        String query = "INSERT INTO catedra (titulo, profesor, dia, turno) VALUES ('JAVA', 'Sergio', 'MIERCOLES', 'TARDE')";
//        Statement st = conn.createStatement();
//        st.execute(query);
//        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM catedra");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("titulo") + ", " +
//                rs.getString("profesor") + ", " +
//                rs.getString("dia") + ", " +
//                rs.getString("turno")
//            );
//        }
//        
//        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
//        conn.close();
//        
//         Connection conn = Connector.getConnection();
//        
//        String query = "INSERT INTO catedra (titulo, profesor, dia, turno) VALUES ('JAVA', 'Sergio', 'MIERCOLES', 'TARDE')";
//        Statement st = conn.createStatement();
//        st.execute(query);
//        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM catedra");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("titulo") + ", " +
//                rs.getString("profesor") + ", " +
//                rs.getString("dia") + ", " +
//                rs.getString("turno")
//            );
//        }
//        
//        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
//        conn.close();
//        
//         Connection conn = Connector.getConnection();
//        
//        String query = "INSERT INTO catedra (titulo, profesor, dia, turno) VALUES ('JAVA', 'Sergio', 'MIERCOLES', 'TARDE')";
//        Statement st = conn.createStatement();
//        st.execute(query);
//        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM catedra");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("titulo") + ", " +
//                rs.getString("profesor") + ", " +
//                rs.getString("dia") + ", " +
//                rs.getString("turno")
//            );
//        }
//        
//        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
//        conn.close(); Connection conn = Connector.getConnection();
//        
//        String query = "INSERT INTO catedra (titulo, profesor, dia, turno) VALUES ('JAVA', 'Sergio', 'MIERCOLES', 'TARDE')";
//        Statement st = conn.createStatement();
//        st.execute(query);
//        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM catedra");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("titulo") + ", " +
//                rs.getString("profesor") + ", " +
//                rs.getString("dia") + ", " +
//                rs.getString("turno")
//            );
//        }
//        
//        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
//        conn.close();
//        
//         Connection conn = Connector.getConnection();
//        
//        String query = "INSERT INTO catedra (titulo, profesor, dia, turno) VALUES ('JAVA', 'Sergio', 'MIERCOLES', 'TARDE')";
//        Statement st = conn.createStatement();
//        st.execute(query);
//        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM catedra");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("titulo") + ", " +
//                rs.getString("profesor") + ", " +
//                rs.getString("dia") + ", " +
//                rs.getString("turno")
//            );
//        }
//        
//        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
//        conn.close(); 
        Connection conn = Connector.getConnection();
        
//        String query = "INSERT INTO alumnos (nombre, apellido, edad, email, idCatedra) VALUES ('Juan', 'Gomez', '25', 'juangomez@gmail.com','1')";
//        Statement st = conn.createStatement();
//        st.execute(query);
        
//        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM alumnos");
//        while (rs.next()) {
//            System.out.println(
//                rs.getInt("id") + ", " +
//                rs.getString("nombre") + ", " +
//                rs.getString("apellido") + ", " +
//                rs.getInt("edad") + ", " +
//                rs.getString("email") + ", " +
//                rs.getInt("idCatedra")
//            );
//        }

        IAlumnoRepository alumno = new AlumnoRepository((java.sql.Connection) conn);
        
//        Alumno alumnoExistente = new Alumno(2, "Carlos", "Diaz", 30, "carlosdiaz@gmail.com",1);
 
//        List<Alumno> alumnos = alumno.getAll();
////        for (Alumno alumno1 : alumnos) {
//            System.out.println(alumnos);
//        }

          Alumno buscarAlumno = new Alumno();
          buscarAlumno = alumno.getById(2);
          
          System.out.println(buscarAlumno);
          
        
//        alumno.update(alumnoExistente);
        
        // Cerrar la conexión y liberar recursos
//        rs.close();
//        st.close();
        conn.close();
    }
}