/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repositorios;

import Entity.Docente;
import Interfaces.IDocenteRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class DocenteRepository implements IDocenteRepository{
    private Connection conn;

    public DocenteRepository(Connection conn) {
        this.conn = conn;
    }
  
    @Override
    public void save(Docente docente) {
        if(docente==null) return;
        //insert into alumnos (nombre,apellido,edad,idCurso) 
        // values ("Anonymus","+x',66,1); delete from docentes; -- +",?,?)",
        try (PreparedStatement ps=conn.prepareStatement(
                "insert into docentes (nombre,apellido,email,idCatedra) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS
        )) {
            ps.setString(1, docente.getNombre());
            ps.setString(2, docente.getApellido());
            ps.setString(3, docente.getEmail());
            ps.setInt(4, docente.getIdCatedra());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) docente.setId(rs.getInt(1));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void remove(Docente docente) {
        if(docente==null) return;
        try (PreparedStatement ps=conn.prepareStatement("delete from docentes where id=?")){
            ps.setInt(1, docente.getId());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Docente docente) {
        if(docente==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
                "update docentes set nombre=?, apellido=?, email=?, idCatedra=? where id=?"
        )) {
            ps.setInt(5, docente.getId());
            ps.setString(1, docente.getNombre());
            ps.setString(2, docente.getApellido());
            ps.setString(3, docente.getEmail());
            ps.setInt(4, docente.getIdCatedra());
            ps.execute();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Docente> getAll() {
        List<Docente> lista=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from docentes")){
            while(rs.next()){
                lista.add(new Docente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("email"),
                        rs.getInt("idCatedra")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lista;
    }
    
}
