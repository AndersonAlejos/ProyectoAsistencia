package Test;

import Connectors.Connector;
import Entity.Docente;
import Interfaces.IDocenteRepository;
import Repositorios.DocenteRepository;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

public class TestDocente {
    public static void main(String[] args) throws SQLException {
        Connection conn = Connector.getConnection();
        
        String query = "INSERT INTO docentes (nombre, apellido, email, idCatedra) VALUES ('Juan', 'Gomez', 'juangomez@gmail.com', '1')";
        Statement st = conn.createStatement();
        st.execute(query);
        
        ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM docentes");
        while (rs.next()) {
            System.out.println(
                rs.getInt("id") + ", " +
                rs.getString("nombre") + ", " +
                rs.getString("apellido") + ", " +
                rs.getString("email") + ", " +
                rs.getInt("idCatedra")
            );
        }
        
          //Cerrar la conexión y liberar recursos
        rs.close();
        st.close();
        conn.close();

//        DocenteRepository docente = new DocenteRepository((java.sql.Connection) conn);
        
//        Docente docenteExistente = new Docente(2, "Carlos", "Diaz", "carlosdiaz@gmail.com",1);
 
//        List<Docente> docente = docente.getAll();
////        for (Docente docente1 : docente) {
//            System.out.println(docente);
//        }

//          Docente buscarDocente = new Docente();
////          buscarDocente = Docente.getById(2);
//          
//          System.out.println(buscarDocente);
          
        
//        docente.update(docenteExistente);
        
       
    }
}
